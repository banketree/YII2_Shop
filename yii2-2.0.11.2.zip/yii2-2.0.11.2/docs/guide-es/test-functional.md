Tests Funcionales
=================

> Note: Esta sección se encuentra en desarrollo.

- [Tests Funcionales de Codeception](http://codeception.com/docs/04-FunctionalTests)

Ejecutar test funcionales de templates básicos y avanzados
----------------------------------------------------------

Por favor consulta las instrucciones provistas en `apps/advanced/tests/README.md` y `apps/basic/tests/README.md`.
