Testy funkcjonalne
==================

> Uwaga: Ta sekcja jest w trakcie tworzenia.

- [Testy funkcjonalne Codeception](http://codeception.com/docs/04-FunctionalTests)

Uruchamianie testów funkcjonalnych dla podstawowego i zaawansowanego szablonu projektu
--------------------------------------------------------------------------------------

Prosimy o zapoznanie się z instrukcjami dostępnymi w plikach `apps/advanced/tests/README.md` i `apps/basic/tests/README.md`.