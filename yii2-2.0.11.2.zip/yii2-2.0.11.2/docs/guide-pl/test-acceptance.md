Testy akceptacyjne
==================

> Uwaga: Ta sekcja jest w trakcie tworzenia.

- [Testy akceptacyjne Codeception](http://codeception.com/docs/03-AcceptanceTests)

Uruchamianie testów akceptacyjnych dla podstawowego i zaawansowanego szablonu projektu
--------------------------------------------------------------------------------------

Prosimy o zapoznanie się z instrukcjami dostępnymi w plikach `apps/advanced/tests/README.md` i `apps/basic/tests/README.md`.
