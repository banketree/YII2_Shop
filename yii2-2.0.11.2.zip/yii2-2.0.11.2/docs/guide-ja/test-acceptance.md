受入テスト
==========

> Note: この節はまだ執筆中です。

- [Codeception Acceptance Tests](http://codeception.com/docs/03-AcceptanceTests)


アプリケーションテンプレートの受入テストを走らせる
--------------------------------------------------

`apps/advanced/tests/README.md` および `apps/basic/tests/README.md` で提供されている説明を参照してください。
