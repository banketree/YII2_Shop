機能テスト
==========

> Note: この節はまだ執筆中です。

- [Codeception Functional Tests](http://codeception.com/docs/04-FunctionalTests)

アプリケーションテンプレートの機能テストを走らせる
--------------------------------------------------

`apps/advanced/tests/README.md` および `apps/basic/tests/README.md` で提供されている説明を参照してください。
