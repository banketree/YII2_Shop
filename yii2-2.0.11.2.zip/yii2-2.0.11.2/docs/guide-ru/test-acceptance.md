Приёмочное тестирование
=======================

> Note: Данный раздел находится в разработке.

- [Codeception Acceptance Tests](http://codeception.com/docs/03-AcceptanceTests)

Запуск тестов в шаблонах проектов basic и advanced
--------------------------------------------------

Инструкции приведены в `apps/advanced/tests/README.md` и `apps/basic/tests/README.md`.
