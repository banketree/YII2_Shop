Функциональные тесты
====================

> Note: Данный раздел находится в разработке.

- [Codeception Functional Tests](http://codeception.com/docs/04-FunctionalTests)

Запуск функциональных тестов для шаблонов проектов basic и advanced
-------------------------------------------------------------------

Следуйте инструкциям в `apps/advanced/tests/README.md` и `apps/basic/tests/README.md`.
